package com.optus.constants;

public class OptusConstants {

	public static final String SEARCH = "/search";
	public static final String TOPWORDS = "/top/{rank}";
}
