package com.optus.entiry;

import java.util.ArrayList;
/**
 * 
 * @author Subbu
 *
 */
public class WordRankPair {
	private ArrayList<String> words;
	private int rank;

	public ArrayList<String> getWords() {
		return words;
	}

	public void setWords(ArrayList<String> words) {
		this.words = words;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

}
